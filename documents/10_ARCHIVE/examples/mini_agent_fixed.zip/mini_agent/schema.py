"""Schema definitions for Mini-Agent"""
from enum import Enum
from typing import Optional, Dict, Any, List
from dataclasses import dataclass


class LLMProvider(Enum):
    """Supported LLM providers"""
    OPENAI = "openai"
    ANTHROPIC = "anthropic"


@dataclass
class Message:
    """Message schema"""
    role: str  # "user", "assistant", "system"
    content: str
    metadata: Optional[Dict[str, Any]] = None

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        return {
            "role": self.role,
            "content": self.content,
            "metadata": self.metadata or {}
        }


@dataclass
class CompletionResponse:
    """Response from LLM completion"""
    content: str
    raw_response: Dict[str, Any]
    usage: Optional[Dict[str, Any]] = None